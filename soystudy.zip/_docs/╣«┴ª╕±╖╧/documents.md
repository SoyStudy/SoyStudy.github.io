---
title: 문제목록
category: 문제목록
order: 1
---

Share documents with your friends! Send work or school projects from your computer or phone.

To share a document:

1. Open a message with someone
2. Select the **Send Media** button
3. Pick a document

> Changes made to documents after sending are not saved back, you'll have to get contacts to send you updated versions.

![](//placehold.it/800x600)
