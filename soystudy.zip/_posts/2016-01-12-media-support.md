---
title: Media support
type: major
---

ChatApp introduces media support! Send images, videos and documents to your contacts.

**Features:**

* Image support
* Video support
* Document support

**Fixes:**

* Edge case contact syncing issue
* All memory leaks obliterated
