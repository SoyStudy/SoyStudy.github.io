---
sort: 8
---

# Mentions Test

```
Hey @saowang, what do you think of this?
```

Hey @saowang, what do you think of this?

```tip
Set config `plugins: [jekyll-mentions]`

For documentation, see: [https://github.com/jekyll/jekyll-mentions](https://github.com/jekyll/jekyll-mentions)
```
